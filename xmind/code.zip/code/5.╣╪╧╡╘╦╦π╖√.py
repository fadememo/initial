莓莓备胎=["关俊杰","朱国华","张兴"]
print("关俊杰"  in 莓莓备胎 ) #关系运算符判断在或者不在
print("尹成"  in 莓莓备胎 )
print("关俊杰"  not  in 莓莓备胎 )
print("尹成"  not  in 莓莓备胎 )