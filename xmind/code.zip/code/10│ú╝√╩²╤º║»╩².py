import math
print(abs(-5)) #数学函数
print(abs(5))
print(math.fabs(-5))
print(math.fabs(5))

print(max(1,2,3,4,5))
print(min(1,2,3,4,5))