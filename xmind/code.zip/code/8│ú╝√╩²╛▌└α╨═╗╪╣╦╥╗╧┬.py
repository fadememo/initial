length=18 #整数,十进制
length=0b11 #二进制
length=0o17 #八进制
length=0x12 #十六进制
print("张宏杰希望有{}cm".format(length))
tall=1.45  #实数
tall=145e-2  #指数
print("张宏杰希望有{}m".format(tall))
print(1+2j) #虚数

print(int(1.45)) #类型转化