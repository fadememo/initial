mystr="hello  meimei,hello lele"
print(mystr.capitalize())#将字符串的第一个字符转换为大写
print(mystr.center(100,"*")) #返回一个指定的宽度 width 居中的字符串，fillchar 为填充的字符，默认为空格。
print(mystr.count("hello"))
print(mystr.encode("utf-8")) #编码为二进制b开头，
print(mystr.encode("utf-8").decode("utf-8"))#二进制转化为字符串
print(mystr.endswith("lele")) #判断是否以某个字符串收尾
print(mystr.find("meimei1")) #查找字符串位置，找到索引，找不到就是-1
print(mystr.isalnum()) #如果字符串至少有一个字符并且所有字符都是字母或数字则返 回 True,否则返回 False
print(mystr.isalpha())#如果字符串至少有一个字符并且所有字符都是字母则返回 True, 否则返回 False
print(mystr.isdecimal()) #十进制数字
print(mystr.isnumeric())#是否数字
print(mystr.join(",")) #以指定字符串作为分隔符，将 seq 中所有的元素(的字符串表示)合并为一个新的字符串
print(len(mystr))#求长度
print(mystr.upper())#大写
print(mystr.lower())#小写
print(mystr.lstrip())#删除左边空格
print(mystr.rstrip())#删除右边空格
print(mystr.strip())#删除前后空格
print(max(mystr))
print(min(mystr))
print(mystr.replace("hello","nimei"))#替换
print(mystr.rfind("hello")) #右边查找
print(mystr.split(","))