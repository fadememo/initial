import random
#随机数
print(random.random())#0-1实数
print(random.randint(0,100)) #整数

import math
print(math.e,math.pi)