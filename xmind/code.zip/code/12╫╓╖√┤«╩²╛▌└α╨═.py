str1="王乐是男"
str2="是女"
print(str1+str2) #加法
print(str1*4) #乘法
print(str1[0]) #取出某个字符
print(str1[:2]) #截取字符串
print("王" in  str1) #判断存在或者不存在
print("王" not in  str1)
print(r"帅锅王乐\n有%d岁，身高%f" % (10,1.67)) #字符串格式化
print("霉女王乐\n有%d岁,身高%f" % (10,1.72)) #r \n当作字符串否则当作换行符
